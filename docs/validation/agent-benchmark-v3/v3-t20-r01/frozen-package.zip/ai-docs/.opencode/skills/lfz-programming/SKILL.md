---
name: lfz-programming
description: 编写、修改或调试 LFZ 语言（.lfz）程序时使用，也用于回答 LFZ 语法/语义问题。给出 #42 首行铁律、语法速查、13 个错误类清单、LFZ 特有的常见陷阱与可运行示例；在本仓库用 `cargo run --quiet -- run <file.lfz>` 运行。
---

# LFZ 编程指南（AI 专用）

> 读者：**未接触过 LFZ 的编程 Agent**。目标：只凭本文件写出**正确、可运行**的 LFZ 程序。
> 事实源：`docs/spec/{syntax,semantics,interface-contract}.md`（含 T12 §16 / T14 §17 / T15 §18 / T16 §19–21）。本文件是**速查/转述**，不定义新语法；与 spec 冲突时以 spec 为准。
> 使用纪律：**只允许使用本文件列出的语法**。不要用 Python / C / JS 的规则去猜 LFZ——LFZ 在若干处刻意不同（见 §4）。
> **版本对齐（2026-11-04，T19准备）**：语言规范共 **76个内置、13类错误**，T19新增forEachLine最终候选5d2219/1041920B已冻结，作者聚焦实跑记录见专属报告；现有dist与旧证据仍按各轮实际hash，不据规范计数推断产物能力。支持argv、JSON、`-e`、stdin源码及非执行check；项目外PATH旧解释器不保证相同能力。T19状态见§6.8及docs/reports/T19-skill-evidence.md。

> 🚫 **硬纪律：不要凭记忆写 LFZ。** 本文件**没写的语法一律视为不存在**；拿不准就先查 §10 列出的 spec，或改用本文件已列出的等价写法。宁可用保守写法，也不要"猜一个大概像 Python 的写法"。

> ⚠️ **第一件事（置顶铁律）**：每个 `.lfz` 文件的**第一行必须是恰好 `#42`（三字符）+ 一个换行**，否则程序以 `CosmosAnswerError: 你忘记了宇宙的答案` 终止。**所有代码示例均须遵守**。详见 §1。

## 0. 触发与用法

- 任务涉及 `.lfz` 文件、LFZ 脚本、`lfz run`、或 `cargo run -- run` 时加载本指南。
- 运行命令（仓库根目录，先 `$env:Path += ";$env:USERPROFILE\.cargo\bin"`）：
  ```bash
  cargo run --quiet -- run <file.lfz>       # 运行一个 LFZ 程序
  cargo run --quiet -- run --json <file>    # 机器可读 JSON 输出
  cargo run --quiet -- test                 # 运行测试集
  ```
- **退出码（按语境区分，详见 §5）**：`0` 成功；**`lfz run` 下 `assert` / `fail` 失败（运行期错误）→ `2`**；**`lfz test` 下有用例失败 → `1`**；CLI 参数错误 / 语法错误 / 运行时错误 / 用例 error → `2`。
- **1.4.0 入口**：`lfz run FILE [-- ARG...]`、`lfz FILE.lfz [-- ARG...]`、`lfz -e CODE [-- ARG...]`（也可 `run -e`）、`lfz - [-- ARG...]`（也可 `run -`）。`-e`/stdin 源码不加 `#42`；REPL 未实现，无参调用仍报错。参数/JSON 工作流见 §6.2。

---

## 0.5 Agent 标准工作流（6 步）——照做，别跳步

> 目标：把"写 LFZ"变成一条**可执行流程**，每步都有**可验证产出**。任何一步没做，都算没完成。

**第 1 步 · 确认头部**：新建的每个 `.lfz` 文件，**第一行恰好是 `#42` + 一个换行**（见 §1）。片段不算交付。

**第 2 步 · 选特性**：只从本文件已有的语法里挑——变量/类型/运算符看 §3，要用的内置函数逐个到 §6 核对**名字、参数、data-last 顺序**。**这一步查不到的名字 = LFZ 没有这个功能**，不要猜、不要用别的语言替代。拿不准时回到顶部硬纪律。

**第 3 步 · 写代码**：一条语句一行；把 §4 的 21 条陷阱当"负面清单"逐条回避。

**第 4 步 · 先检查**：运行 `lfz check <file.lfz>`，exit0才进入执行阶段；检查不求值，具体边界见§0.6。

**第 5 步 · 实跑（强制，不可省）**：按任务授权运行，核对副作用、stdout/stderr及退出码；正常成功场景**必须看到退出码 `0`**：

```bash
$env:Path += ";$env:USERPROFILE\.cargo\bin"
cargo run --quiet -- run <file.lfz>   # 期望：正确 stdout + exit=0
$LASTEXITCODE                         # 必须打印 0
```

出现报错（退出码 `2`）→ 用 **§4.5「错误类 → 原因 → 修法」**定位，改完**再跑**。**没跑过 = 没写完。**

**第 6 步 · 交付前自检**：逐条过 **§8 自检清单**，全勾后再交。

---

## 0.6 先检查，再执行（T14）

依据三spec §17。以下 `lfz` 指本项目候选解释器；Windows可用 `.\dist\lfz.exe`。项目外PATH中的旧版不保证有check。

```powershell
lfz check job.lfz
lfz check --json -e 'print(1 / 0)'
# stdout: {"ok":true,"mode":"check","executed":false}；exit 0
'print(1 / 0)' | lfz check --json -
# 同上；不打印、不触发除零
```

- 三来源：`check FILE`、`check -e CODE`、`check -`。文件沿run的加载规则，`.lfz`首行仍须精确`#42`加换行；非.lfz文件豁免。CODE/stdin不要求、不消费该前导；stdin读UTF-8到EOF。
- check只加载、词法、语法及现有AST深度检查，不求值。正常成功stdout/stderr均空、exit0；前端失败stderr诊断、stdout空、exit2。源内`print`/`eprint`/`;;`/`input`/文件IO/无限循环不执行；读取待检查源码和stdin仍是宿主IO。它不是安全沙箱，也不检查未定义名、类型、运行期arity、IO路径或终止性。
- 合法check加`--json`：成功严格三键`ok:true,mode:"check",executed:false`；前端失败为`ok:false,mode:"check",executed:false`，再接原`error,message,file,line,col,traceback`字段。stdout恰一行、stderr空。带位置traceback只是单个`<module>`定位记录，不是实际执行栈；无位置IO错误line/col为null、traceback为空。
- CLI参数错误是例外：即使有`--json`，仍stderr用法文本、stdout空、exit2。不要无条件json解析任意失败调用。
- `-e`紧随的一项原样作为CODE，包括空串、`--json`、`--`、`--help`。CODE外`--json`可前后重复；check拒绝CODE外任何`--`及脚本参数、缺源/多源/缺CODE/未知选项和`check --help`。帮助用`lfz --help`。
- check通过只代表前端通过。`print(1 / 0)`检查成功，但run会ZeroDivisionError；先check成功，再按任务授权和预期副作用执行run并核对结果。执行阶段参数才放在`--`后。
- CLI `lfz check`与源码内非致命断言`check(cond,msg)`不同；T14未新增内置；当前T15新增attempt后共73。旧run/test JSON不增加mode/executed键。
- 本轮为1.4.0候选，R304仍OPEN，不是正式发布或整体提速声明。新增指南作者实跑另见`docs/reports/T14-skill-evidence.md`；旧v2的8/8、131/131属于原冻结输入，不重新计分。

## 1. ⚠️ 铁律（第 1 条，最先看）：`.lfz` 文件首行必须是 `#42`

**规则**：任何 **`.lfz` 文件**的**第一行必须恰好是 3 个字符 `#42`**，其后**紧跟一个行终止符**（`\n`、`\r\n`、`\r`）。

- 违反 → 程序以 **`CosmosAnswerError: 你忘记了宇宙的答案`** 终止（退出码 `2`）。
- **只按扩展名触发**：扩展名（ASCII 大小写不敏感）为 `lfz` 才要求，`.lfz` / `.LFZ` / `.Lfz` 都算。
- **豁免**：`run` 加载的非 `.lfz` 文件，以及 `-e` / stdin 源码；后两者不要求、不消费 `#42`。REPL 仍未实现。
- **无任何变体**（违反即 `CosmosAnswerError`）：`# 42`、`#42 `（尾随空格）、`#42\t`、`##42`、`#43`、`#42abc`、首行前的空行/空格/Tab。
- **只有 3 字节 `#42` 而无换行符** → 也不行。**空 `.lfz` 文件** → 也不行。
- **BOM 豁免**：文件开头可有 UTF-8 BOM（`EF BB BF`），跳过后再要求 `#42`。
- **`#` 的位置**：只在 `.lfz` **首行前导位**合法。程序中间（CODE 模式）出现 `#` → `SyntaxError`（消息 `'#' 只能出现在文件首行的前导位；(字符串 / 注释 / 格式说明符内的 '#' 除外)`）。**字符串 / 注释 / 格式说明符内的 `#` 是普通字符**。
- **片段示例**：若只给代码片段，须注明「作为 `.lfz` 文件时首行须为 `#42`」。

**完整最小程序**（可直接运行）：

```lfz
#42
print("Hello, LFZ!")
```

实测：`cargo run --quiet -- run docs\guide\ai\examples\01_hello.lfz` → `Hello, LFZ!`（退出码 `0`）。

---

## 2. 错误类清单（13 个具体类 + 基类）

> 用户可见输出**只有类名 + 中文消息**，**不存在任何编号错误码**（不要写、也不要期待形如「字母-数字」的内置错误编号）。
> `check` 失败**不抛错**（见 §5）。

| 错误类 | 触发条件 | 中文消息示例 | 阶段 |
|---|---|---|---|
| `LfzError`（基类） | 不直接抛出 | — | — |
| `CosmosAnswerError` | `.lfz` 文件缺合法 `#42` 前导 | `你忘记了宇宙的答案` | 加载 |
| `SyntaxError` | 词法/语法错：非法字符、字符串未闭合、块注释未闭合、未列举转义、整数越界、意外记号、单 `;`、同行两语句、赋值目标非法、`#`/`_` 位置非法、管道多 `_`、`break`/`continue` 在循环外、`return` 在函数外、非 UTF-8 | `非法字符 '$'`；`单独的 ';' 非法；打印变量请用 ';;'`；`语句之间必须有换行`；`文件不是合法的 UTF-8 编码（首个非法字节位于字节偏移 {off}）` | 加载/解析 |
| `NameError` | 引用未定义的名字 | `未定义的名字 'x'` | 运行 |
| `TypeError` | 运算符/条件/调用/参数/格式说明符类型不符；调用非函数；管道右侧非函数；参数个数不符；**重绑定 `let` 变量** | `条件必须是 bool，得到 int`；`运算符 '+' 不支持 int 与 string`；`不能重新赋值 let 变量 'a'；let 只锁重绑定，不锁内容` | 运行 |
| `IndexError` | 数组下标越界（含负索引规范化后越界） | `下标 5 越界（长度 2）` | 运行 |
| `FieldError` | struct 缺该字段（`.k` / `["k"]` 读取缺失键；`del` 的键不是数据字段） | `结构体没有字段 'missing'` | 运行 |
| `ZeroDivisionError` | `/`、`%`、`div(a,b)` 的除数为零（**含 float**） | `除以零` / `对零取模` | 运行 |
| `OverflowError` | `int` 运算超出 i64；`int(±Inf)`；`int(float)` 截断后超 i64 | `整数溢出：结果超出 i64 范围` | 运行 |
| `ValueError` | 转换失败（`int("abc")`、`int(NaN)`）；非法格式说明符；空数组取极值；`randInt(lo>=hi)` | `无法把 string 转换为 int（'abc'）`；`格式说明符非法：'{spec}'`；`空数组没有极值（min）`；`区间非法：3 >= 2` | 运行 |
| `IOError` | `input()` 遇 EOF；不可读文件 | `输入结束（EOF）`；`无法读取：{path}` | 运行 |
| `AssertionError` | **仅** `assert(cond,msg)` 失败 或 `fail(msg)` | `断言失败：{msg}`；`{msg}`（`fail`） | 运行 |
| `RecursionError` | 求值帧深度 > 10000，或深结构处理超限 | `递归深度超限（超过 10000 层）` | 运行 |
| `ExecutionLimitError` | 求值步数耗尽、取消token或deadline | `执行步数预算已耗尽` / `执行已取消` / `执行时间上限已到` | 运行（T17） |

**实测消息样本**（`--json` → 退出码均为 `2`）：

```
int("abc")            → ValueError: 无法把 string 转换为 int（'abc'）
int(float("nan"))     → ValueError: 无法把 float 转换为 int（'nan'）
int(float("inf"))     → OverflowError: 整数溢出：结果超出 i64 范围
min([])               → ValueError: 空数组没有极值（min）
1 / 0                 → ZeroDivisionError: 除以零
[1,2][5]              → IndexError: 下标 5 越界（长度 2）
{ k: 1 }.missing      → FieldError: 结构体没有字段 'missing'
对 let 变量再次赋值    → TypeError: 不能重新赋值 let 变量 'a'；let 只锁重绑定，不锁内容
9223372036854775807+1 → OverflowError: 整数溢出：结果超出 i64 范围
```

**错误输出形态**：加载/解析期错误（`CosmosAnswerError` / `SyntaxError`）**无** `Traceback` 头；运行期错误（其余 10 类）**有** `Traceback (most recent call last):` 头。示例（运行期）：

```
Traceback (most recent call last):
  File "demo.lfz", line 2, in <module>
    let r = 1 / 0
            ^
ZeroDivisionError: 除以零
```

---

## 3. 语法速查（骨架）

> 以下片段若作为 `.lfz` 文件，**首行须为 `#42`**。为省版面，标题外的块示例只在完整程序中标注。

**变量与绑定**

```lfz
let x = 1        // let：不可重绑定（内容可改，见 §4-4）
var y = 2        // var：可重绑定
y = y + 1
```

**字面量与类型**：`int`（`1_000`、`0xFF`、`0b1010`、`0o755`）、`float`（`3.14`、`2.5e-3`、`1e10`）、`string`（`"..."`，**只有双引号**）、`bool`（`true`/`false`）、`nil`、`array`（`[1, 2, 3]`）、`struct`（`{ k: 1 }` 或 `Name { ... }`）、`function`。

**运算符（高→低，全左结合）**：postfix `() [] .` > 一元 `- !` > `* / %` > `+ -` > `|>` > `< <= > >=` > `== !=` > `&&` > `||`。

**字符串插值**：`"${expr}"`；一条字符串可含**多个** `${}`（如 `"${a}-${b}-${a}"`，按书写序求值）。

**格式说明符**（写在 `${}` **内**、紧跟 `:`）：
- **对齐** `align` ∈ { `<` 左, `>` 右, `^` 居中 }，可带 **fill** 字符：`${"ab":<5}` → `[ab   ]`、`${"ab":>5}` → `[   ab]`、`${"ab":^5}` → `[ ab  ]`、`${42:0>5}` → `[00042]`、`"${"ab":*^7}"` → `[**ab***]`。
- **宽度 / 精度 / 类型**：`${f:.2f}`、`${n:05d}`、`${n:x}`。
- **宽度必须是字面数字**：`${"ab":>w}` → `ValueError: 格式说明符非法：'>w'`（**不支持动态宽度**）。需要变宽补齐 → 用 `repeat(n, fill)` 手工拼（注意 §4.6 的 O(n) 提醒）。

转义仅这些：`\n \t \r \\ \" \e`（ESC）、`\$`。**未列出的转义（如 `\q`、`\{`）→ `SyntaxError`**。`{` / `}` 在字符串内是普通字符。

**if（语句 / 表达式）**

```lfz
if cond { ... } else { ... }
if a { ... } else if b { ... } else if c { ... } else { ... }   // else if 链：合法
let v = if cond { a } else { b }                                 // if 是表达式，可赋值
```

**while / for**

```lfz
while cond { ... }
for x in xs { ... }        // array（迭代开始时取元素快照）
for k in s { ... }         // struct 数据字段键，按字节序升序
```

**函数 / lambda**

```lfz
fn add(a, b) { a + b }        // 块体：末尾表达式即返回值
fn add(a, b) => a + b         // 表达式体
let dbl = (x) => x * 2        // lambda
let inc = fn(x) { x + 1 }     // 函数字面量
```

**结构体（模板 + 方法）**

```lfz
struct Point {
    x: 0,
    y: 0,
    fn norm2() => self.x * self.x + self.y * self.y,
}
let p = Point { x: 3, y: 4 }
print(p.norm2())
```

**管道 `|>`（data-last）**

```lfz
let r = [1, 2, 3, 4] |> filter((x) => x % 2 == 0) |> map((x) => x * 10) |> sum()
let q = 10 |> push(_, [1, 2])      // _ 占位：注入到该位 → push(10, [1, 2])
```

**`;;`（变量 dump）**：独立一行，把当前可见变量按 `name ： value` 写 **stdout**（内层→外层、遮蔽去重）。

**注释**：`//` 行注释；`/* ... */` 块注释（**不可嵌套**，未闭合到 EOF → `SyntaxError`）。

**赋值**：`=` `+=` `-=` `*=` `/=` `%=`；左侧 lvalue 可为 `x`、`a[i]`、`s.k`，**可链式**：`t[i][j] = v`、`p.inner.x = v`（合法；下标/字段赋值**就地修改**容器）。

**零参 `print()` / `eprint()`**：合法，只打印一个换行（`print(...)` 空格连接各参 + 换行）。

**`&&` / `||` 短路求值**：两侧与结果都必须是 `bool`；`len(xs) > 0 && xs[0] == 1` 在 `xs == []` 时**不会**求右侧（不越界）；`||` 同理。

---

## 4. 常见陷阱（AI 最易踩；均已实测）

> 这些是 LFZ 与 Python/C 的**刻意差异**，逐条给「错误写法 → 结果 → 正确写法」。
> 本节片段若作为 `.lfz` 文件，首行须为 `#42`。

1. **`;` 是非法语句分隔符**（不是必需，也不是可省略）。
   - 错误：`let x = 1; let y = 2` → `SyntaxError: 语句之间必须有换行`；单独 `;` → `SyntaxError: 单独的 ';' 非法；打印变量请用 ';;'`。
   - 正确：**一条语句一行**，不要写 `;`。**打印变量用 `;;`**（独立一行）。

2. **`/` 恒为真除法，返回 `float`**：`7 / 2 == 3.5`（不是 3）。
   - 整数向下取整用内置 **`div(a, b)`**：`div(7, 2) == 3`、`div(-7, 2) == -4`。

3. **`%` 为 Python 取模，结果符号随除数**：`-7 % 3 == 2`、`7 % -3 == -2`。

4. **`let` 不可重绑定，`var` 可以**：`let a = 1` 后再 `a = 2` → `TypeError`。
   - 但**容器内容可原地改**：`let a = [1]; a[0] = 2` **合法**（`let` 只锁重绑定，不锁内容）。

5. **`if` 是表达式**，可赋值：`let g = if c { "high" } else { "low" }`。

6. **换行终结语句；续行只能用括号**（`()` / `[]` / 字面体 `{}`）。
   - 错误：`let x = 1 +\n2`、行首以 `|>` 或 `.` 续行 → `SyntaxError`。
   - 正确：`let x = (1 +\n 2)`。

7. **`=>` 后紧跟的 `{` 恒为块**：`fn f() => { 1 }` 是块体。
   - 要在箭头位返回 struct 字面量必须加括号：`fn f() => ({ k: 1 })`。

8. **`${...}` 内是 CODE 模式**：里面的字符串用**普通双引号**。
   - 正确：`print("x = ${"a" + "b"}")`。
   - 错误：在 `${}` 内写 `\"`（`\` 在 CODE 模式非法）→ `SyntaxError: 非法字符 '\'`。插值内**禁止换行**。

9. **管道是 data-last**：`xs |> f(a)` = `f(a, xs)`（无 `_` 时把 `xs` 追加为**末参**）。
   - `_` 占位：`10 |> push(_, [1, 2])` = `push(10, [1, 2])`。
   - `_` 只能出现在**管道右侧调用的实参**中，且**不得穿 lambda**：`xs |> map((x) => x + _)` → `SyntaxError`。

10. **容器内置返回新值，不改原容器**（函数式更新）：
    - `let ys = push(9, xs)` —— **不**改 `xs`；`sort(xs)` 不改 `xs`。
    - 唯一原地改的是**赋值语法** `a[i] = v` / `s.k = v`。

11. **76 个内置按 data-last 约定**（见 §6）；容器/字符串被操作对象恒为末参。

12. **`round` 是银行家舍入（四舍六入五成双）**：`round(2.5) == 2`、`round(3.5) == 4`。

13. **`int(float)` 边界**：向零截断 `int(2.9) == 2`、`int(-2.9) == -2`；`int(float("nan"))` → `ValueError`；`int(float("inf"))` / `int(1e30)` → `OverflowError`。

14. **`float` 特值**：`sqrt(-1)` → `nan`；`float("inf")` / `float("nan")` 合法；显示为 `nan` / `inf` / `-inf`；整值浮点带 `.0`（`str(1.0) == "1.0"`）。

15. **关键字不能作字段名**：`let` `var` `fn` `return` `if` `else` `while` `for` `in` `break` `continue` `struct` `true` `false` `nil` `self`。
    - 错误：`r.self`、`{ self: 1 }` → `SyntaxError`。
    - 正确：用字符串键 `r["self"]`、`{ "self": 1 }`。

16. **无 truthiness、无隐式转换**：`if`/`while`/`&&`/`||`/`filter` 谓词等**必须是 `bool`**，否则 `TypeError`。唯一隐式转换是 `int → float` 加宽（`|int| > 2^53` 时可能不精确）。

17. **`==` 是深结构相等且环安全**：`array`/`struct` 按内容；`function` 仅**同一性**；自引用容器显示 `<cycle>`，不报错、不死循环。

18. **空数组取极值报错**：`min([])` / `max([])` / `minBy(...)` / `maxBy(...)` → `ValueError: 空数组没有极值（min）`。

19. **字符串只用双引号**，没有单引号；不存在 `->`、`++`、`..`、`|`、`&`、`::`、`>>` 等记号（会拆开或报错）。

20. **`insert` 不支持负索引**（合法域 `i ∈ [0, len]`）；`removeAt`/`swap` 支持负索引。`pop([])` → `IndexError: 下标 -1 越界（长度 0）`。

21. **`del(k, s)` 只作用于数据字段**（方法字段视为缺失 → `FieldError`）：不变量 `del(k,s) 成功 ⟺ has(k,s) == true`。

22. **字符串不可下标**：`s[i]` 对 `string` → `TypeError: 运算符 '[]' 不支持 string 与 array / struct`。
    - `[]` **只适用于** `array`（`int` 下标，支持负索引）与 `struct`（`string` 键）。**读写同源**（`s[0] = v` 与 `s[0]` 报同一条）。
    - **正确**：先 `split("", s)` **一次性 O(n)** 拆成单字符数组，之后 `cs[i]` / `for c in cs` 都是 **O(1)**：
      ```lfz
      let cs = split("", "abc")   // ["a", "b", "c"]
      print(cs[0])                // a
      for c in cs { print(c) }    // 顺序遍历，整段 O(n)
      ```
    - 复杂度：`split("", s)` = O(n)（n = 字符数）。若改用 `s[i]`（必然实现为 `chars().nth(i)`）遍历会退化成 **O(n²)**——这正是 LFZ 刻意不提供 `s[i]` 的原因。

23. **循环体内 `let` / `var` 每轮都是新绑定**（各自新 cell）：在 `while` / `for` 体里写 `let x = ...` **合法**，**无需**提升到循环外，也**不会**报「不能重新赋值 let」。闭包各自捕获**当轮** cell（A2）：
    ```lfz
    var fs = []
    var i = 0
    while i < 3 {
        let x = i * 10
        fs = push(fn() => x, fs)
        i += 1
    }
    for f in fs { print(f()) }   // 0 / 10 / 20（若共用 cell 会是 20/20/20）
    ```

24. **容器内置返回新值 ⇒ 别在循环里用 `push` / `+` 累积**（A1）：`push(v, xs)` 每次克隆整个数组、`s = s + c` 每次复制整个前缀，**循环累积都是 O(n²)**。大 n 请用 **§4.6** 的 O(n) 写法。

---

## 4.5 错误类 → 最常见原因 → 修法（把 §2 的错误类与 §4 的陷阱串起来）

> 用法：**先看报错类名**（§2），再到本表定位"你大概率踩了哪条"，按"改法"动手，然后回 §0.5 第 4 步重跑。
> 记住：**报错信息里没有编号**，只有**类名 + 中文消息**；消息里的中文关键字是排查的第一线索。

| 你看到的（类名 / 消息关键字） | 大概率踩了 | 改法（正确写法） |
|---|---|---|
| `CosmosAnswerError: 你忘记了宇宙的答案` | 首行不是恰好 `#42`+换行（§1） | 首行**只有** `#42` 三字符（无空格、无尾随、无前导空行） |
| `SyntaxError: 语句之间必须有换行` | 用 `;` 分隔语句 / 一行两语句（§4-1） | **一条语句一行**，删掉 `;` |
| `SyntaxError: 单独的 ';' 非法；打印变量请用 ';;'` | 想用 `;` 打印变量（§4-1） | 打印变量用**独立一行的 `;;`** |
| `SyntaxError: 非法字符 '\'` | `${...}` 内写了 `\"`（§4-8） | `${}` 内是 CODE 模式 → 用**普通双引号 `"`**；插值内禁止换行 |
| `SyntaxError: 非法字符 '…'`（其它符号） | 用了别的语言的记号（`->` `++` `..` `\|` `&` `::` `>>` `'`）（§4-19） | 换 LFZ 等价写法；字符串**只用双引号** |
| `SyntaxError` 出现在跨行处 | 行尾挂运算符 / 行首 `.` `\|>` 续行（§4-6） | 断行**必须放进括号内**（`()` `[]` `{}`） |
| `SyntaxError: '#' 只能出现在文件首行的前导位…` | 在程序中间写了 `#`（§1） | `#` 只允许在 `.lfz` 首行前导位 |
| `SyntaxError`（块注释/字符串未闭合相关） | 忘记 `*/` / `"`，或块注释嵌套（§3） | 补闭合；块注释**不可嵌套** |
| `SyntaxError`（字段位） | `.self` / `{ self: 1 }` 等关键字当字段名（§4-15） | 用**字符串键**：`r["self"]` / `{ "self": 1 }` |
| `SyntaxError`（管道内） | `_` 出现在多参 / 穿 lambda（§4-9） | `_` 只能在**管道右侧调用的实参**里，且**不得穿 lambda** |
| `TypeError: 不能重新赋值 let 变量 'x'` | 对 `let` 变量重绑定（§4-4） | 需要重赋值改用 **`var`**；只改内容用 `a[i]=` / `s.k=`（合法，`let` 只锁重绑定） |
| `TypeError: 条件必须是 bool，得到 int` | 用了 truthiness（§4-16） | 显式写 `x != 0` / `len(xs) > 0` |
| `TypeError: 运算符 '+' 不支持 int 与 string` | 无隐式转换（§4-16） | 用 **`str(x)`** 显式转换再拼接 |
| `TypeError`（调用非函数 / 参数个数不符 / 管道右侧非函数） | 名字拼错，或参数顺序没按 **data-last**（§3 管道、§6） | 到 **§6** 核对签名；管道默认把左值注入**末参** |
| `NameError: 未定义的名字 'x'` | 变量/函数名拼错，或未定义就用（§2） | 先定义后使用；检查拼写与作用域 |
| `IndexError: 下标 … 越界（长度 …）` | 下标越界 / `pop([])` / `insert` 负索引（§4-20） | 用 `len` 判界；`insert` 合法域 `[0, len]` |
| `FieldError: 结构体没有字段 'k'` | 读了缺失键，或 `del` 的是方法字段（§4-21） | 先 **`has(k, s)`** 判断再读 |
| `ZeroDivisionError: 除以零` / `对零取模` | `/` `%` `div` 除数为 0（§2） | 先判零；整除用 `div(a,b)` |
| `OverflowError: 整数溢出…` | `int` 越 i64，或 `int(±Inf)` / `int(1e30)`（§2） | 收窄数值，或改用 `float` |
| `ValueError: 无法把 string 转换为 int（'abc'）` | `int("abc")` 转换失败（§2） | 只对数字串 `int`，或先校验字符 |
| `ValueError: 空数组没有极值（min）` | 对空数组 `min/max/minBy/maxBy`（§4-18） | 先判 `len(xs) > 0` |
| `ValueError: 格式说明符非法：…` | 格式串拼错 / 用了**动态宽度**（§3 插值） | 用 `:>6` `:<6` `:^6` `:0>5`（fill+对齐）、`:.2f`、`:05d`、`:x`；**宽度须字面数字**，动态宽度用 `repeat` 手工补（§3） |
| `TypeError: 运算符 '[]' 不支持 string 与 array / struct` | 对 **string** 取下标（§4-22） | 字符串不可下标 → 先 `split("", s)`，再对数组索引 |
| `ValueError: 区间非法：lo >= hi` | `randInt(lo, hi)` 且 `lo >= hi`（§6） | 保证 `lo < hi`（区间为 `[lo, hi)`） |
| `IOError: 输入结束（EOF）` | 在无输入环境用了 `input()`（§6） | 提供实际输入；stdin 源码模式已读到 EOF，不能再从同一 stdin 提供数据 |
| `AssertionError: 断言失败：…` | `assert`/`fail` 条件不成立（§5） | 复核条件；**软校验用 `check`**（非致命） |
| `RecursionError: 递归深度超限（超过 10000 层）` | 递归无终止条件 / 太深（§2） | 补终止条件，或改写成 `while`/`for` 循环 |

---

## 4.6 性能红线：O(n) 字符串 / 数组构建（避免隐藏 O(n²)）

> 背景：LFZ 的 `string` **不可变**（§4.5.11），`array` 内置**返回新值**（A1）。这两条叠加，使「在循环里逐步累积」极易写成 **O(n²)**。
> 下表为**实测**（当前 `dist\lfz.exe`，循环 N 次，单位毫秒，≈值）。**关键反直觉结论：把 `s = s + c` 换成 `push` 累积并不会变快，反而更慢。**

| 写法（循环 N 次） | N=40000 | N=80000 | N=160000 | N=320000 | 复杂度 |
|---|---|---|---|---|---|
| ❌ `var s=""` + `s = s + "x"` | 61 | 139 | 425 | 1582 | **O(n²)** |
| ❌ `var a=[]` + `a = push("x", a)` + `join("", a)` | 251 | 674 | 4076 | —（超时） | **O(n²)** |
| ✅ `range(n) |> map((i) => "x") |> join("")` | 25 | 35 | 56 | 104 | **O(n)** |
| ✅ 预分配 + 下标写 `arr[i] = ...` + `join` | 33 | — | 85 | 151 | **O(n)** |

**为什么 `s = s + c` 是 O(n²)**：`string + string` 的实现是 `format!("{a}{b}")`——每次生成**新串并复制整个前缀**（源码：`src/evaluator.rs:1496`）。循环 n 次 ⇒ 复制总量 `1+2+…+n = Θ(n²)`。
**为什么 `push` 累积也是 O(n²)**：`push(v, xs)` 遵守 A1「返回新数组」，内部先 `xs.to_vec()` **整体克隆**（源码：`src/builtins.rs:385`）。循环 n 次同样是 Θ(n²)，且常数比字符串拼接更大。**这是最反直觉的点。**

**正确的 O(n) 惯用法（二选一）：**

1. **每段是下标的函数** → `range(n) |> map(f) |> join("")`（`range` + `map` + `join` 各 O(n)，全程只分配一次）：
   ```lfz
   #42
   let n = 5
   let s = range(n) |> map((i) => str(i * i)) |> join(",")
   print(s)   // 0,1,4,9,16
   ```
2. **需要条件累积** → 先**预分配**长度为 n 的数组，再用**下标赋值**（唯一原地写语法 `a[i] = v`，O(1)）逐格写入，最后 `join`：
   ```lfz
   #42
   let n = 3
   let arr = range(n) |> map((i) => "")   // 预分配 n 个空串（O(n)）
   var i = 0
   while i < n {
       arr[i] = str(i * 10)               // 原地写，O(1)
       i += 1
   }
   print(arr |> join("-"))                // 0-10-20
   ```

> 小数据量（n ≤ 几千）差异可忽略；**大 n（≥ 10⁴）务必用上表的 ✅ 写法**。同理，`len(string)` 是 O(n)，长串循环里别反复调用（见 §6 `len`）。

---

## 5. `check` 非致命 / `assert` 致命

| 函数 | 失败时行为 |
|---|---|
| `assert(cond, msg?)` | 抛 **`AssertionError`（致命）**，终止，退出码 `2` |
| `check(cond, msg?)` | 向 **stderr** 写一行 `check 失败：{msg}`，返回 `false`，**继续运行**，**不改变退出码、不产生错误** |
| `fail(msg?)` | 抛 **`AssertionError`（致命）** |

> **退出码按语境区分（消除歧义，实测）**：**`lfz run`** 下 `assert` / `fail` 失败 → `AssertionError` → 退出码 **`2`**（它是一次运行期错误）；**`lfz test`** 下由 runner 把该用例记为 **failure** → 退出码 **`1`**。**同一个含 `assert(1 == 2)` 的程序**：`lfz run` → exit `2`；`lfz test <目录>` → exit `1`（报告 `失败 1`）。不要把两个语境的结果混为一谈。

实测：

```lfz
#42
check(1 == 2, "soft")
print("continue")
```

→ stdout：`continue`；stderr：`check 失败：soft`；**退出码 `0`**。把 `check` 换成 `assert` 则退出码 `2`。

---

## 6. 内置函数 76 个（data-last）

> **约定**：凡对容器 / 字符串操作者，**被操作对象恒为最后一个参数**；`xs |> f(...)` 把 `xs` 注入末参。**凡容器更新一律返回新值、不改原容器**（A1），除非用赋值语法 `a[i]=` / `s.k=`。参数类型/个数不符 → `TypeError`。

**核心 / 数组（22）**：`len` `range` `push` `pop` `removeAt` `insert` `swap` `slice` `min` `max` `sum` `minBy` `maxBy` `sort` `sortBy` `map` `filter` `reduce` `take` `drop` `each` `contains`

- **`len(x) -> int`**：`array` 元素数 / `struct` **数据字段**数（不含方法）/ **`string` 的 Unicode 标量数**（**合法**：`len("abc") == 3`、`len("日本語") == 3`、`len("😀") == 1`、`len("") == 0`）。⚠️ `len(string)` 是 **O(n)**（需扫描标量，非字节数）；长串循环里别反复调用，先 `split("", s)` 后对数组求 `len`（O(1)）。
- **`range(n) -> array[int]`**：`[0, 1, …, n-1]`（**半开区间**，物化为普通数组，O(n) 时间 + O(n) 内存）；`n < 0` → `[]`（`range(0)` 亦为 `[]`）。另支持 **`range(lo, hi) -> array[int]`**：物化半开区间 `[lo,hi)`，`hi <= lo` → `[]`；非空时 O(hi−lo) 时间/内存。只接受 1 或 2 参，均须 int；0 参消息 `函数 range 期待 1 个参数，得到 0`，3 参消息 `函数 range 期待 2 个参数，得到 3`。容量超限 → `OverflowError: 容量溢出：所需容量超出可分配上限`。
- `push(v, xs)`、`pop(xs)`、`removeAt(i, xs)`、`insert(i, v, xs)`、`swap(i, j, xs)`、`slice(from, to, xs)`（**均返回新数组**，见 §4-24 / §4.6）
- `map(f, xs)`、`filter(pred, xs)`（`pred` 必须返回 `bool`）、`reduce(f, init, xs)`（`f(acc, x)`）、`take(n, xs)`、`drop(n, xs)`、`each(f, xs)`
- `min(xs)`/`max(xs)`（全序；空 → `ValueError`）、`minBy(keyFn, xs)`/`maxBy(keyFn, xs)`、`sum(xs)`（全 `int` → `int`，含 `float` → `float`，空 → `0`）、`sort(xs)`/`sortBy(keyFn, xs)`（稳定升序）

**struct（5）**：`keys` `values` `entries` `has` `del`

- `keys(s)`/`values(s)`/`entries(s)` 按键的 **UTF-8 字节序升序**；只含**数据字段**（方法字段不含）。
- `has(k, s) -> bool`；`del(k, s) -> struct`（新 struct；键不是数据字段 → `FieldError`）。

**字符串（13）**：`split` `join` `trim` `upper` `lower` `replace` `repeat` `startsWith` `endsWith` `indexOf` `padEnd` `padStart` `substring`

- `split(sep, s)`（**`sep` 为空串 → 按字符拆成单字符数组**：`split("", "abc") == ["a", "b", "c"]`，一次 **O(n)**；这是字符串「取字符」的正解，见 §4-22）、`join(sep, xs)`（元素须为 string）、`replace(old, new, s)`、`repeat(n, s)`、`startsWith(prefix, s)`。

**数值 / 转换 / IO / 断言（29）**：`abs` `floor` `ceil` `round` `sqrt` `pow` `div` `rand` `randInt` `seed` `str` `int` `float` `type` `print` `eprint` `input` `assert` `check` `fail` `sin` `cos` `log` `exp` `ord` `chr` `readFile` `writeFile` `appendFile`

- `div(a, b) -> int`（向下取整；两参须 `int`）。
- `round(f) -> int`（银行家舍入）；`floor`/`ceil`/`round` 的 `NaN` → `ValueError`，`±Inf`/超界 → `OverflowError`。
- `abs(x)` **同型**（`int→int`、`float→float`，绝不加宽）；`sqrt(f) -> float`（`f<0` → `NaN`）；`pow(a,b) -> float`。
- `int(x)`：`string`/`float`/`bool` → `int`；`float` 向零截断；`NaN` → `ValueError`，`±Inf`/超界 → `OverflowError`。
- `float(x)`：`int`/`string`/`bool` → `float`；支持 `"inf"`/`"-inf"`/`"nan"`。
- `type(x) -> string`：`"int"` / `"float"` / `"string"` / `"bool"` / `"nil"` / `"array"` / `"struct"` / `"function"`。
- `randInt(lo, hi) -> int`（`[lo, hi)`；`lo >= hi` → `ValueError`）；`rand() -> float`（`[0,1)`）；`seed(n)` 固定随机序列。
- `print(...)`（空格连接 + 换行，stdout）、`eprint(...)`（stderr）、`input(prompt?)`（EOF → `IOError`）。

### 6.1 本轮新增 15 个内置：完整签名与边界

被操作的容器/字符串放末参；例如 `"日本語" |> substring(1, 3)`，`"内容" |> writeFile("Temp/out.txt")`。字符串操作返回新串。字符指 **Unicode 标量**，不是 UTF-8 字节或字素簇；组合字符/含 ZWJ 的 emoji 可含多个标量。`s[i]` 仍不合法，读取字符用 `split("", s)[i]`。

| 签名 | 已实现行为与复杂度 |
| -- | -- |
| `contains(v, xs) -> bool` | 仅 array；深结构、环安全 `==` 比较。O(n) 次比较（深比较可大于 O(1)）；N 次循环反复搜索长数组为 O(N·M)。struct 键用 `has(k,s)`。 |
| `endsWith(suffix, s) -> bool` | 空后缀 true；O(m)，m 为后缀长度。 |
| `indexOf(sub, s) -> int` | 首次匹配的标量下标；未找到 -1；空 sub 返回 0。保守最坏 O(n·m)，不宣称 O(n)。 |
| `padEnd(width, fill, s) -> string` | 右补至标量宽度；len(s)>=width 返回原串；fill 重复、按标量截断。O(n+m+输出宽度)，包括主串/fill 计数。 |
| `padStart(width, fill, s) -> string` | 左补，其余同 padEnd。 |
| `substring(from, to, s) -> string` | 标量半开区间，两端夹取到 `[0,len(s)]`，from>=to 返回空串；负数不从尾计。非空结果 O(min(to,len(s)))（to 先夹至非负），UTF-8 需扫描前缀；空区间可直接返回。 |
| `ord(c) -> int` | c 须恰好一个标量的 string；成功 O(1)，非法字符串完整统计 n，错误路径 O(n)。非 string → TypeError；标量数≠1 → `ValueError: ord 的参数必须是单个字符（Unicode 标量数 {n}）`。 |
| `chr(n) -> string` | n 须 int，0..1114111 且排除代理区 55296..57343；O(1)。非 int → TypeError；非法码点 → `ValueError: chr 的参数不是合法的 Unicode 码点：{n}`。 |
| `sin(f) -> float` | int 加宽；正弦；±Inf/NaN → NaN，O(1)。 |
| `cos(f) -> float` | int 加宽；余弦；±Inf/NaN → NaN，O(1)。 |
| `log(f) -> float` | int 加宽；自然对数；log(0) → -Inf，负数 → NaN，O(1)。 |
| `exp(f) -> float` | int 加宽；e 的 f 次方；溢出 → +Inf，O(1)。 |
| `readFile(path) -> string` | path 须 string；UTF-8 全量读取，O(文件大小) 时间/内存。 |
| `writeFile(path, contents) -> nil` | 两参须 string；UTF-8 覆盖写，不存在则创建；O(文件大小)。 |
| `appendFile(path, contents) -> nil` | 两参须 string；UTF-8 追加，不存在则创建；O(追加大小)。 |

`padEnd`/`padStart` 的 fill 为空（即使无需补齐）→ `ValueError: 填充串不能为空`；width/from/to 非 int、字符串形参非 string → TypeError。math 采用 IEEE，NaN/Inf 本身不抛 ValueError/OverflowError；转换/取整规则仍见 §6。int 加宽超过 2^53 可能丢精度。

文件路径原样交给 OS；相对路径基于**进程 CWD**（不是脚本目录），不展开 `~`、不规范化、不自动建父目录。当前项目只在项目内读写，临时件放 `Temp/`；内置本身不实施沙箱。错误均为 `IOError`：读失败 `无法读取：{path}`；非法 UTF-8 `无法读取：{path}（不是合法的 UTF-8 编码）`；写失败 `无法写入：{path}`；追加失败 `无法追加：{path}`。`writeFile(p,42)` 不隐式转换，应先 `str(42)`。外部 IO 依赖环境。大量片段遵循 §4.6，避免循环拼接或 push 的 O(n²)。

完整可运行增量示例及 stdout/退出码见 `docs/reports/T11-v11-skill-evidence.md`，使用项目内 `dist/lfz.exe`（1.4.0）。

---


## 6.2 Agent 数据脚本：argv、JSON 与直接执行（1.4.0）

| API | 签名与边界 |
| -- | -- |
| `argv()` | 零参 → 新 `array[string]`；不含程序/脚本名或 `--`；无参数为 `[]`。每次返回新数组，修改它不会改下次参数。 |
| `jsonParse(text)` | 严格单个 JSON → LFZ 值；`null`→`nil`，object→匿名 struct；必须传 string。 |
| `jsonStringify(value)` | JSON 可表示值 → 无换行紧凑 string；对象数据字段按 UTF-8 键序输出。 |

**复制调用模板（PowerShell，仓库根目录）**。其中 `-e` 的 CODE 是片段，若保存为 `.lfz` 则仍须首行 `#42`：

```powershell
.\dist\lfz.exe -e 'print(jsonStringify(argv()))' -- '中文' '--json' ''
# stdout: ["中文","--json",""]
.\dist\lfz.exe -e 'print(jsonStringify(argv()))' --json -- '--json'
# stdout: {"ok":true}；业务 JSON ["--json"] 写 stderr
.\dist\lfz.exe run Temp/job.lfz -- CONFIG.json INPUT.json OUTPUT.json
```

- `--` 后每项原样传给 `argv()`，空串/Unicode/`--json`/`-e`/`--help` 都是数据；无 `--` 的额外参数报 CLI 错误。
- `-e` 下一项**无条件是 CODE**；例如 `lfz -e --json` 把 `--json` 当源码报错，不能把它吞成选项。CODE 之后的 `--json` 才是机器输出选项。
- **业务 JSON**：正常模式 `print(jsonStringify(value))` 写 stdout；**CLI `--json`**：stdout 只写执行状态/错误对象，程序 print/dump/input 提示转 stderr，不返回最后表达式。不要把业务输出与状态对象混在一起解析。
- `lfz -` / `lfz run -` 把 stdin **全部 UTF-8 源码**读到 EOF，错误路径名 `<stdin>`；读失败/非法 UTF-8 为 `IOError: 无法读取标准输入`。此时程序 `input()` 会遇 EOF；代码与数据不要共用这个入口。文件/`-e` 模式仍可用 `input()` 读取单行输入。
- `argv` 是本轮唯一新增的一等内置值：可 `let getArgs = argv` 后调用；`argv == argv` 为 true，`type(argv)` 为 `"function"`，`str(argv)` 为 `"<fn argv>"`。词法变量/形参优先，可遮蔽它；保存的别名仍有效。**JSON 两内置与旧69内置未泛化为一等值**，写 `map((s) => jsonParse(s), texts)`，不要写 `map(jsonParse, texts)`。

**完整程序：参数传配置，管道处理，确定性业务 JSON 输出。** 保存为 `Temp/job.lfz`；传入唯一参数 `{"title":"中文🙂","values":[1,2,3,4]}`（操作系统参数分词由调用者负责）：

```lfz
#42
let args = argv()
assert(len(args) == 1, "需要一个 JSON 配置参数")
let config = jsonParse(args[0])
let values = config.values |> filter((x) => x % 2 == 0) |> map((x) => x * 10)
let result = { title: config.title, count: len(values), total: sum(values) }
print(jsonStringify(result))
```

stdout：`{"count":2,"title":"中文🙂","total":60}`，exit 0。来自文件的 JSON 同样用 `readFile(path) |> jsonParse()`，输出用 `writeFile(path, jsonStringify(value))`；先验证/编码完成，再写文件，避免错误路径覆盖已有输出。无需自写 JSON parser，也不要用字符串拼接构造 JSON。

**严格数据边界**（spec 契约 §16.2–16.3）：

- 整数词法按 i64 精确解析，`9007199254740993` 不降为 float；超出 `[-9223372036854775808,9223372036854775807]` 报错。含小数点/指数的数字为有限 f64；允许舍入/下溢至零，保留负零。编码整值 float 补 `.0`，重新解析仍为 float。
- 禁止 BOM、注释、尾逗号、重复**解码后**对象键、非法前导零、NaN/Inf、裸控制字符及孤立 UTF-16 代理；正确代理对、Unicode/NUL 转义可往返。JSON 文本内 `$`/`${...}` 是数据，不进行 LFZ 插值；序列化不产生非法 JSON 转义 `\$`。
- 解析/编码最多同时打开 **128 层 array/object**；标量深度0，128允许，129拒绝。当前路径上的循环引用拒绝；共享但无环的子对象可在多个位置编码。
- struct 按既有 A5 数据面**跳过函数方法字段**，其余键稳定排序；函数根值、数组函数元素和 struct 模板拒绝。不会调用方法，不把非法值改成 null。
- `ValueError: JSON 解析失败（字节偏移 {offset}）：{reason}`。offset 从0计 **UTF-8 字节**，不是字符数；reason 为 `不是合法的 JSON` / `对象键重复` / `整数超出 i64 范围` / `浮点数超出有限范围` / `嵌套深度超过 128 层`。
- `ValueError: JSON 编码失败：{reason}`，reason 为 `不支持函数或结构体定义` / `浮点数必须有限` / `循环引用` / `嵌套深度超过 128 层`。非string解析参数/数量错误为 TypeError。错误位置仍指 LFZ 内置调用点，run exit2；`--json` 提供结构化诊断。

**效率约束**：继续使用 §4.6 的 map 或预分配，不用循环 push/字符串累积。JSON 单遍字节游标与一次容器构造；解析 O(n+Σk log k)，编码包含展开输出和键排序成本（字符串比较另计）。struct 内部字段索引改善**平均**查找，不承诺最坏 O(1)，排序/复制/编码也不因此变成 O(1)。性能实测由 `docs/reports/T12-performance.md` 提供，本指南不把源码改动直接称为加速。

## 7. 可运行示例（分级，含真实输出）

> 全部示例在仓库根目录以 `cargo run --quiet -- run <path>` 实跑通过（退出码 `0`）。源文件见 `docs/guide/ai/examples/`。

### L1 — Hello

```lfz
#42
print("Hello, LFZ!")
```

输出：
```
Hello, LFZ!
```

### L2 — 类型 / 算术陷阱 / `if` 表达式 / 插值 / `;;`

```lfz
#42
let name = "LFZ"
var count = 3
count = count + 1

print("hello, ${name}")
print("7 / 2 = ${7 / 2}")
print("div(7, 2) = ${div(7, 2)}")
print("-7 % 3 = ${-7 % 3}")
print("round(2.5) = ${round(2.5)}")
print("round(3.5) = ${round(3.5)}")

let grade = if count > 3 { "high" } else { "low" }
print("grade = ${grade}")

;;
```

输出：
```
hello, LFZ
7 / 2 = 3.5
div(7, 2) = 3
-7 % 3 = 2
round(2.5) = 2
round(3.5) = 4
grade = high
name ： LFZ
count ： 4
grade ： high
```

### L3 — struct + 方法 + 管道 + lambda + 插值（稍复杂综合）

```lfz
#42
struct Student {
    name: "",
    score: 0,
    fn isTop() => self.score >= 90,
    fn line() => "${self.name}: ${self.score:>3}",
}

fn average(xs) {
    var total = 0.0
    for s in xs { total += float(s.score) }
    total / float(len(xs))
}

let roster = [
    Student { name: "Alice", score: 93 },
    Student { name: "Bob", score: 67 },
    Student { name: "Cara", score: 88 },
]

let ranked = roster |> sortBy((s) => -s.score)
print("ranking (desc):")
for s in ranked { print("  " + s.line()) }

let names = roster |> map((s) => s.name) |> join(", ")
print("members: ${names}")
print("average: ${average(roster):.2f}")
let top = roster |> maxBy((s) => s.score)
print("top: ${top.name} (${top.score})")
```

输出：
```
ranking (desc):
  Alice:  93
  Cara:  88
  Bob:  67
members: Alice, Bob, Cara
average: 82.67
top: Alice (93)
```

### L4 — struct + 方法（带参）+ `while` + 管道 + 插值（词频统计，综合工作流范例）

> 源文件：`docs/guide/ai/examples/04_wordcount.lfz`。演示 §0.5 工作流的完整闭环。

```lfz
#42
struct Counter {
    counts: {},
    total: 0,
    fn bump(w) {
        if has(w, self.counts) {
            self.counts[w] = self.counts[w] + 1
        } else {
            self.counts[w] = 1
        }
        self.total += 1
    },
    fn top(n) => self.counts |> entries() |> sortBy((e) => -e[1]) |> take(n),
    fn report() => "total=${self.total}, distinct=${len(self.counts)}",
}

fn count_all(ws) {
    let c = Counter {}
    var i = 0
    while i < len(ws) {
        c.bump(ws[i])
        i += 1
    }
    c
}

let text = "the quick brown fox jumps over the lazy dog the fox jumps the"
let words = text |> split(" ")

let c = count_all(words)
print(c.report())
print("top 3 words (desc):")
for e in c.top(3) {
    print("  ${e[0]}: ${e[1]:>2}")
}
```

输出（实测，exit `0`）：
```
total=13, distinct=8
top 3 words (desc):
  the:  4
  fox:  2
  jumps:  2
```

> 注意点：`entries(s)` 返回 `[[key, value], ...]`，按**键升序**；`sortBy` 稳定，故并列计数按键序；`take(n, xs)` 用管道写作 `... |> take(n)`（data-last）。

### L5 — 字符串与索引惯用法（覆盖 §4-22 / §4-23 / §4.6 与插值对齐）

> 本示例为 SKILL 内联（人类向示例在 `docs/guide/ai/examples/`）；实测证据见 `VERIFICATION.md` §8。

```lfz
#42
// 字符串不可下标 → 先 split("", s)，之后索引 O(1)
let cs = split("", "LFZ")            // ["L", "F", "Z"]
print(cs)
print(cs[0])
print(cs[2])

// 循环体内 let 每轮新绑定；闭包各自捕获当轮 cell
var fs = []
var i = 0
while i < len(cs) {
    let c = cs[i]
    let f = fn() => upper(c)
    fs = push(f, fs)
    i += 1
}
for f in fs { print(f()) }

// 对齐说明符（< 左 / > 右 / ^ 居中 + fill）；宽度须字面数字
let rows = [["ab", 7], ["c", 128]]
for r in rows {
    print("[${r[0]:<4}|${r[1]:>5}|${r[0]:*^6}]")
}

// else if + 零参 print() + && / || 短路
fn bucket(n) {
    if n >= 100 { "big" }
    else if n >= 10 { "mid" }
    else { "small" }
}
print(bucket(7))
print()
let xs = []
print(len(xs) > 0 && xs[0] == 1)     // false，短路不越界
print(len(xs) == 0 || xs[0] == 1)    // true
```

输出（实测，exit `0`）：
```
["L", "F", "Z"]
L
Z
L
F
Z
[ab  |    7|**ab**]
[c   |  128|**c***]
small

false
true
```

---

## 8. 交付前自检清单（逐项打勾）

- [ ] 已先check再run，分别保存检查和执行结果？check成功未当成运行成功？
- [ ] CLI check与源码check断言区分，usage错误的--json文本例外已处理？

- [ ] 每个 `.lfz` 文件**首行恰好 `#42` + 换行**？（无变体、无前导空白）
- [ ] 没有用 `;` 作语句分隔或打印变量？（打印变量用 `;;`，独立一行）
- [ ] 是否把 `/` 误当整除？（整除用 `div`）
- [ ] 有没有对 `let` 变量重绑定？（不可；改用 `var`，或只改容器内容 `a[i]=`）
- [ ] 所有条件/逻辑运算/`filter` 谓词都是 `bool`？（无 truthiness）
- [ ] 跨行是否都在括号内？（行尾运算符、行首 `.`/`|>` 不续行）
- [ ] `${}` 内是否误写 `\"`？（应写普通 `"`；插值内不换行）
- [ ] 管道是否 data-last / `_` 位置合法（在 RHS 实参内、不穿 lambda）？
- [ ] 是否依赖容器内置**原地修改**？（须接收返回的新值）
- [ ] 字段名是否误用了关键字？（用 `r["self"]`）
- [ ] 字符串是否用了**单引号**？（LFZ 只有双引号）
- [ ] 是否写/期待了旧的编号错误码？（**禁止**；只有类名 + 中文消息）
- [ ] 代码块是否都含 `#42` 首行？（片段是否注明）
- [ ] **没有对 `string` 取下标**？（`s[i]` → `TypeError`；先 `split("", s)` 再对数组索引，见 §4-22）
- [ ] 脚本参数是否放在 `--` 后？业务 JSON 是否与 CLI `--json` 状态区分？JSON 是否用内置而非手写拼接/解析？
- [ ] **大 n 下没有在循环里用 `s = s + ...` 或 `push` 累积**？（O(n²)；用 §4.6 的 `range |> map |> join` 或「预分配 + 下标写」）
- [ ] 循环体内用了 `let`？（**可以**，每轮新绑定——不要因此改用 `var` 提升到循环外，见 §4-23）
- [ ] 退出码是否按语境理解？（`lfz run` 下 assert 失败 → `2`；`lfz test` 下用例失败 → `1`）
- [ ] 格式说明符宽度是否为**字面数字**？（动态宽度不支持 → 用 `repeat` 手工补，见 §3）

---

## 9. 提示模板（复制即用）

```
你是一名 LFZ 程序员。只允许使用后面给出的《LFZ 编程指南》中列出的语法，
禁止联想到 Python/C/JS 的语法来补全。输出必须是**完整可运行**的 `.lfz` 文件
（含首行 #42），不要伪代码、不要零散片段。

任务：<在此描述你要写的小程序，例如：读取一个整数数组，用管道 filter/map/reduce 求和并打印>

交付要求：
1. 每个 `.lfz` 文件首行恰好为 #42；
2. 自己对照指南 §8 自检清单逐项检查；
3. **不要对字符串取下标**（`s[i]` 非法，用 `split("", s)`）；**大 n 时不要在循环里 `s = s + …` 或 `push` 累积**（O(n²)，见指南 §4.6）；
4. 先check再按任务授权run，保存两步真实结果；check不执行，不保证运行成功。
5. 给出预期的 stdout 输出。
```

**最小任务基线**（用来验证「只看指南能否写对」）：写一个函数，接收整数数组，返回偶数元素之和；用管道 `filter`/`reduce` 实现；打印结果。`[1,2,3,4,5]` → `6`。参考解（实测通过）：

```lfz
#42
fn sum_even(xs) {
    xs |> filter((x) => x % 2 == 0) |> reduce((acc, x) => acc + x, 0)
}
print(sum_even([1, 2, 3, 4, 5]))
```

输出：`6`

---

## 10. 权威来源

- 语法：`docs/spec/syntax.md`｜语义：`docs/spec/semantics.md`｜接口/错误/内置表：`docs/spec/interface-contract.md`（含 T12 §16 / T14 §17 / T15 §18 / T16 §19–21）。
- runner/CLI 契约：`docs/tooling/runner-contract.md`。
- 本指南的实测验证记录：同目录 `VERIFICATION.md`（§8 为 T11-③ 的 D1–D7 修订实测证据）。
- 本 skill 包的**安装与使用**：同目录 `README.md`（三种安装方式 + 运行前提 + 不做什么）。
- 示例源码目录：`docs/guide/ai/examples/`（`01_hello` / `02_basics` / `03_students` / **`04_wordcount`**）。
- AI指南入口：`docs/guide/ai/README.md`（与本文件内容同步）；人类向手册：`docs/guide/README.md`。


## 6.3 T15：把业务错误变为可检查的值

事实源为三spec §18；语言内置总数为73（原72加attempt），并未使内置普遍成为一等函数。先用项目内候选 `lfz check` 检查，再run，最后核结果和副作用。

`attempt(f)`恰一参，f必须是可零参调用的函数；只调用一次。成功为新struct `{ok:true,value:v,error:nil}`，失败为 `{ok:false,value:nil,error:e}`，三字段插入序固定。成功nil仍是ok=true；不要用value是否nil判断成功。value保持原引用与函数身份，不深复制。

失败e字段插入序为 `class,message,line,col,traceback`；位置1-based整数、未知位置nil。traceback为完整外→内数组，每帧字段序 `func,line,col`，函数名含`<module>`/`<fn>`。无file字段（解释器上下文没有源路径），它不同于CLI错误JSON的traceback协议。记录是普通数据，改记录不会改解释器内部栈。

```lfz
#42
let lines = ["{\"n\":2}", "bad", "{\"n\":5}"]
var values = []
var errors = []
for line in lines {
 let r = attempt(() => jsonParse(line))
 if r.ok { values = push(r.value, values) }
 else { errors = push(r.error, errors) }
}
assert(len(values) == 2 && len(errors) == 1)
assert(errors[0]["class"] == "ValueError")
print(jsonStringify({values: values, errors: errors}))
```

`class`是保留字，必须用`r.error["class"]`，不能写`r.error.class`。lambda内空struct须写`({}).missing`，`=> {}`本来就是块。

捕获白名单为NameError、TypeError、IndexError、FieldError、ZeroDivisionError、ValueError、IOError、AssertionError、整数越界OverflowError。JSON128深度输入验证属ValueError。容量溢出、RecursionError、SyntaxError、CosmosAnswerError以及宿主panic/abort/分配失败不捕获；不得用attempt吞资源终止。IOError沿原运行时类别，不保证识别所有底层OS资源故障。

参数求值、attempt参数数量/类型和f非零形参校验均在本次捕获边界外，直接报原错误；外层attempt可捕内部发生的TypeError。旧内置非一等值，写`attempt(() => jsonParse(text))`，不要写`attempt(jsonParse)`。argv是既有特例，`attempt(argv)`合法并返回参数快照。attempt自己不是一等函数，不能`let saved=attempt`；可用命名调用/管道，也可按原词法规则遮蔽。

成功及可恢复失败还原调用前depth与完整trace（包括调用者span），嵌套各自独立；不可恢复错保留故障栈传播。func_names/next_func_id不回滚，失败回调写出的逃逸闭包仍有效。

**没有事务回滚**：容器/全局/cell写入、文件写入、print/eprint、随机状态和闭包分配均保留。check(false)只是警告和false，attempt仍成功；assert/fail在边界内是失败值。成功value可含函数或环，不能承诺整个Result一定能jsonStringify。结构化业务失败可以让run退出0，必须自行检查每条ok，不能以进程exit0代表所有记录成功。

实用完整应用见`app/jsonbatch.lfz`；当前readFile整文件驻内存，不是流式读取。新作者实跑见`docs/reports/T15-skill-evidence.md`，不覆盖旧v2冻结成绩。R304仍OPEN，无T15性能测窗，不声明提速或正式发布。


## 6.4 T16-C：本地模块的Agent工作流

事实源三spec §19–21及T16-C-design；C候选支持本地模块执行，73内置不增加。先为每个.lfz保留#42首行，写静态import/export，先check整个根模块图（不初始化、不执行IO），通过后才run并核业务输出。check成功不保证依赖初始化或入口求值成功。不要把多个文件文本拼接成共享globals。

同目录`counter.lfz`：

```lfz
#42
var base = 40
let shared = [1]
fn add(x) => base + x
fn bump() { base += 1
 base }
export base, shared, add, bump
```

同目录`main.lfz`：

```lfz
#42
import lib from "./counter.lfz"
var base = 900
assert(lib.add(2) == 42)
assert(lib.bump() == 41)
assert(lib.base == 40)
lib.shared[0] = 7
print(jsonStringify({answer: lib.add(2), args: argv(), shared: lib.shared}))
```

执行`lfz check --json main.lfz`，应只得到`{"ok":true,"mode":"check","executed":false}`；再`lfz run main.lfz -- '中文'`，业务输出为`{"answer":43,"args":["中文"],"shared":[7]}`。先检查后执行两步都须保留证据。

- 语法仅`import alias from "./relative.lfz"`、`export a, b`，都是直接顶层声明。所有import须在其它语句之前，export也算其它语句；导出只限本模块直接顶层绑定。无动态/远程import、包搜索、from-import或live循环绑定。
- 路径相对导入者文件目录；-e/stdin根以开始捕获cwd为基址。必须无插值相对.lfz路径（可含..）；不补扩展名、不接受绝对/网络路径。不把symlink/..解析当权限沙箱。依赖按canonical身份去重，每次执行独立缓存；同模块多alias/菱形只初始化一次，按导入书写序依赖后序串行执行。
- 模块全局独立。导出函数在定义模块home globals中执行，调用者同名变量不污染它；捕获局部cell和self保持原规则。namespace是普通struct，标量为初始化完成时快照，容器/函数共享原引用拓扑。改namespace标量字段不回写原模块绑定；多alias共享namespace对象。keys/JSON沿A5过滤函数，不是完整函数导出反射。
- 所有模块使用同次argv输入快照，argv()每次仍新数组。跨执行不复用初始化缓存。初始化失败立即停止，尚未运行入口内attempt无法捕获依赖初始化错误，无隐式重试。
- 跨模块未捕获错误的CLI human/JSON使用真实定义文件及逐帧来源，参数/arity错误属于调用者。不要拼路径到func名。attempt仍是既有三/五/三字段且无file，只有各帧行列，不能由它声称完整文件定位；恢复还原module/source上下文但不回滚用户副作用、实例或函数ID。
- 导出模板先`let P = lib.Point`再`P{}`，不支持`lib.Point{}`。graph模板默认表达式在定义globals/captured cells/self上下文、按字段序每次重新求值，可变默认每实例独立；全部默认先完成，显式覆盖才在caller Scope按书写序求值。错误可见`Point::<defaults>`及真实定义文件。无模块legacy模板保留原caller默认值规则，不新增默认帧。
- check完整图在初始化前拒绝循环、别名/绑定冲突、缺导出、坏路径/前导/UTF8/语法；读取未导出namespace字段是运行时FieldError。图上限1024节点/含根128层/单文件2MiB/总原始16MiB，根admission例外与精确顺序以§20为准；不宣称OS资源隔离。
- Rust嵌入：旧eval_module*只保留无模块行为，带模块Program仍guard拒绝。构建ModuleGraph，在on_eval_stack内调用eval_graph_traced_on_thread_with_args(&graph,&args)，parse/build/eval/drop均同大栈；不能重读图文件或克隆所有Program。外层GraphExecutionError::InvalidGraph/Origins是宿主不变量错误（CLI stdout空/stderr宿主异常/exit2），内层TracedRun.result才是LFZ错误，不被attempt吞宿主错。UserFn手写literal按§19补home_module；StructDef按§21补default_context，旧struct_def/struct_template helper保持None，graph使用TemplateContext与struct_template_in_context。ModuleId与SourceId不可互换，无Loaded不能借其它文件画下划线。

完整人类示例见docs/guide/modules.md；本AI新增作者实跑见docs/reports/T16-C-skill-evidence.md。R304仍OPEN，无C性能成绩，不声明正式发布；不改写旧v2成绩与输入。


## 6.5 T17：Agent先检查，再带执行限额运行

三spec §22为唯一精确契约。内置仍73，新增第13个错误类ExecutionLimitError（旧12类消息与触发保持）。先`lfz check --json job.lfz`，通过后才运行`lfz --max-steps 200 --timeout-ms 1000 run job.lfz`，最后核业务结果及已发生副作用。检查成功只代表前端/模块图通过；不要给check传执行限额。

```lfz
#42
let total = sum([1, 2, 3])
print(total)
```

`--max-steps N`、`--timeout-ms N`仅支持独立两token，每项至多一次；N为非空ASCII数字且可表示为u64，允许0/前导0。拒绝符号/空白/小数/下划线/溢出；**等号写法全部拒绝**（含空值），精确usage消息为`选项 '--max-steps' 不支持等号写法，请使用 '--max-steps N'`，另flag同形。等号族扫描到立即报usage，不能由--help/--version忽略。选项可在执行来源前后，与--json组合；语法错误/图验证优先于求值限额。check/test/--help/--version不接受执行限额。使用既有`--help`/`--version`，不新增裸help/version命令或改变同名文件行为。

CODE紧邻-e的一个原始token不再解析为选项，即使恰为--max-steps=1、--timeout-ms或--json；源码中的双负号按旧LFZ语法/求值，不自动成为CLI usage。完整执行来源后的--进入argv保护，之后任何同名flag/等号/空串都原样传入脚本；没有分隔符不得多传脚本参数。

步骤是每次进入exec_stmt和eval_expr各一步，不是源行数/循环次数/CPU指令或每native元素。N允许N次节点进入，下一节点才报耗尽：源码`1`需2步；`let x=1`换行`x`需4步。零语句程序即使步数0或timeout0也成功，不额外poll。空for的循环控制不虚构每轮节点，不能因它迭代多就承诺小预算可终止。每poll优先取消token→deadline→余量0；都未触发才减余量。poll发生于当前节点自身求值副作用之前，已完成父/兄弟节点的副作用不回滚。

资源错误消息固定：步数“执行步数预算已耗尽”、取消“执行已取消”、时间“执行时间上限已到”。CLI运行exit2，--json仍原唯一错误对象、真实line/col/file/traceback，不新增预算统计键；程序输出仍按原机器模式走stderr。**attempt不能捕获ExecutionLimitError，业务恢复不补步、不重置token或延长deadline。**模块初始化、函数、7高阶回调、闭包/方法/graph模板默认值共用session预算，缓存模块不重复初始化。跨模块fault定位真实当前来源，不用caller文件替代；旧attempt三/五/三字段仍无file。

时间上限是协作式求值窗口：CLI在前端（含完整图）成功后、eval前建立Instant deadline；不包含源码加载/解析/静态图/输出渲染。只在stmt/expr边界检查，大range、JSON、排序、format、input/readFile等native可能持续阻塞；若末次native完成后没有下一节点，可能成功返回，即使期间已到期或收到取消。不是硬实时超时、CPU/内存/文件沙箱，也不会强杀解释线程。

取消是**Rust库API**的Arc<AtomicBool> token，host用store(true,Release)，poll load(Acquire)，Interp不reset；不是CLI Ctrl-C新功能。Ctrl-C仍OS默认，不保证结构化Cancelled。EvalLimits{max_steps,deadline,cancel}按值传新*_with_args_and_limits入口；每调用余量独立，Clone只共享token身份，明确复用已取消token则下一节点均取消。旧入口Default unlimited；坏graph仍先返回宿主GraphExecutionError。禁止LFZ Value/Env跨线程共享。精确三个入口签名及大栈职责见interface-contract §22.2，不擅自发明wrapper。

T17作者聚焦实跑见docs/reports/T17-skill-evidence.md。无新增Agent盲测，不改旧v2；R304OPEN，未做本轮性能验收，不宣传unlimited零成本或正式发布。


## 6.6 T18-A：显式授权的工具执行（本轮到此停止）

三spec §23与T18-A-design为事实源。新增exec后共74内置，仍13错误类；exec不是新一等函数值，使用命名调用或closure包装。仅Windows后端已实施/实测，其它平台受控Unsupported，不能宣传Linux/macOS可执行或权限沙箱；本轮不包含HTTP。

Agent工作流：明确待执行工具及参数，先check确认脚本/模块图，再按任务授权加`--allow-process`和全局限额run；核业务返回值、子进程exitCode及已发生副作用。check不执行exec，也不隐式授权；能力默认禁用且仅当前session，模块共享同次权限，函数home不携带权限，后续执行不继承授权。

```lfz
#42
let tool = argv()[0]
let result = exec([tool, "echo", "a b", "中文"], 5000, 1024)
print(jsonStringify(result))
```

将以上保存为job.lfz，先`lfz check --json job.lfz`，再`lfz --allow-process --max-steps 1000 --timeout-ms 10000 run job.lfz -- ABSOLUTE_FIXTURE_EXE`。示例echo模式是本项目测试fixture接口，不能假设任意工具都提供echo；真实任务换为明确工具协议，路径须替换为实际允许的绝对.exe。不得通过PATH猜测工具位置或擅自改成shell命令拼接。

`exec(argv, timeoutMs, maxOutputBytes)`恰3参：argv非空string数组，全元素先验类型后逐索引验NUL和值；argv[0]必须非设备盘符绝对.exe或UNC.exe路径，拒相对/盘符相对/.bat/.cmd/设备路径，不搜索PATH、不隐式shell。用户显式选择绝对shell.exe仍可能运行shell，故本接口不声称阻止shell。Windows保证标准C运行时命令行解码约定，不声称内核有argv数组。其它空串/空格/Unicode参数原样传；stdin为null/EOF，继承host环境和cwd，没有env/cwd/stdin扩展、无隐式重试。

timeoutMs为int 1..600000；maxOutputBytes为int 0..16777216，stdout+stderr**合并raw byte**计数，等于上限可成功，超过失败；不是字符数，不是每stream各一份额度。0用于无输出工具。成功返回新struct，字段序`stdout,stderr,exitCode,signal`；stdout/stderr是返回值，**不自动转发终端**。非零退出仍是普通成功值，需要Agent自己检查exitCode；Windows退出码u32扩为i64、signal=nil。每stream内序保留，不承诺两个流的跨流全序。严格UTF8，BOM/CRLF原样保留，不合法则整个ProcessUtf8 ValueError，不返回部分成功。

参数校验完整发生于spawn前，并先于能力/平台/全局预检，禁用错误`ValueError: 子进程能力未启用`。局部timeout、输出超量、坏UTF8及路径/参数/禁用/Unsupported均沿§23 ValueError可用attempt包装；OS操作故障为IOError，消息前缀`子进程{operation}失败：`。全局取消/deadline是ExecutionLimitError，**attempt不能吞掉**，业务恢复不补步；exec原生等待不扣AST步，也不会仅因remaining=0自行StepBudget。exec有原生协作poll并在普通成功前末检，不能把T17其它native末次成功例外误套exec。

同轮可观测优先级为取消→全局deadline→局部timeout→合并超量→读/进程OS错误→普通完成；首次确定主reason锁存。局部deadline从首次成功启动后建立、覆盖运行与输出drain；spawn及内核异常不保证硬实时中断。Windows Job/受控双pipe/回收后代是受控生命周期机制，不是恶意进程/权限逃逸隔离、CPU/内存沙箱。正常返回也不允许后台Job残留，但不能承诺OS不可中断场景下绝对回收时限。

CLI `--allow-process`无值且不可重复；`--allow-process=任意文本`立即usage“选项 '--allow-process' 不接受值”。只用于执行来源，check/test/--help/-h/--version/-V拒绝。CODE紧邻-e及完整来源后-- argv仍原样保护。混合限额/能力选项：扫描错误按token序优先；扫描都成功、最终为非执行命令时，取选项区首次新类别的唯一文案（能力先为“子进程能力选项只适用于运行命令”，限额先为“执行限额选项只适用于运行命令”），忽略--json，CODE/argv不参与类别。不要新增裸help/version别名。

正常--json仍唯一原状态/错误对象，子进程输出留返回值；**cleanup宿主异常有例外**：主错误存在则原错误JSON保留、独立回收诊断写stderr；result成功但host_diagnostics非空时CLI stdout空/stderr“lfz: 子进程资源回收失败”及诊断/exit2，即使--json也不能伪装成功JSON。attempt捕获IOError不能清除回收诊断。Rust宿主必须检查TracedRun.host_diagnostics()，不能只看result Ok；EvalContext包含limits与显式EvalCapabilities{subprocess}，所有旧API默认禁用，无global/thread_local泄漏，精确三个context入口见§23.3。

作者聚焦实跑见docs/reports/T18-A-skill-evidence.md。旧v2输入/成绩不变；R304OPEN，未性能验收，不正式发布。本轮交付后停止，不进入HTTP等后续迭代。


## 6.7 T18-B：显式授权HTTP（最终候选）

事实源三spec §24及T18-B-contract；75内置/13错误类。此节为本轮已授权HTTP工作流，覆盖A阶段“交付后停止不HTTP”的旧边界；B本轮交付后收口，不自动T19，不恢复自动化。不能以T18-A旧字节声称HTTP通过。先check图不执行，再对明确目标显式--allow-http并带限额run，核response.status和业务body，不只看进程exit0。

```lfz
#42
let base = argv()[0]
let paths = ["/data", "/missing"]
var records = []
for path in paths {
 let r = attempt(() => httpRequest("GET", base + path, [], "", 1000, 16384))
 if r.ok { records = push({path: path, status: r.value.status, body: r.value.body}, records) }
 else { records = push({path: path, error: r.error}, records) }
}
print(jsonStringify(records))
```

保存fetch.lfz，先`lfz check --json fetch.lfz`，再`lfz --allow-http --max-steps 1000 --timeout-ms 5000 run fetch.lfz -- 'http://127.0.0.1:PORT'`。PORT来自自己启动的loopback服务，不是固定端口；本例/data返回UTF8 JSON，/missing返回404。仅默认不做真实公网调用；验证器使用本地临时port且完整shutdown。

`httpRequest(method,url,headers,body,timeoutMs,maxResponseBytes)`六参，特殊非一等内置、可同名遮蔽。成功struct固定键序`status,headers,body`：404/500等HTTP状态也是正常值，不抛HTTP业务错；headers是[[lowercaseName,value],...]保重复/API观测序，不是字典，不合并Set-Cookie，不保证原wire大小写；body严格UTF8，保BOM/换行，不猜charset、不lossy、不自动jsonParse，不支持任意二进制。jsonStringify仍按自身规则排序键。

完整参数校验发生在触网前，精确先后依§24.1。方法仅ASCII大写GET/HEAD/POST/PUT/PATCH/DELETE/OPTIONS；URL绝对http/https、最多16384 ASCII bytes，非ASCII路径先percent编码，拒userinfo/fragment/反斜线/空白/控制/NUL和非法百分号。headers最多256对、每对恰两个string，ASCII token名和可见ASCII/SP/HTAB值（提交去两端SP/HTAB），拒CR/LF/NUL和保留头Host/Content-Length/Transfer-Encoding/Connection/Proxy-Authorization/Proxy-Connection/Accept-Encoding/Upgrade；原请求头ASCII字节最多65536。body UTF8<=16MiB，GET/HEAD必须空；timeoutMs 1..600000、maxResponseBytes 0..16777216。不要把任意LFZ字符直接塞进URL/header。

HTTP能力默认禁用，独立于--allow-process；只当前session有效，跨模块共享、不同执行不泄漏，不让attempt或函数home升级权限。check/test/--help/-h/--version/-V拒--allow-http，CODE/来源后-- argv保护保持。该flag无值、不可重复，等号形式立即usage。不新增裸help/version别名。混process/http/limits时扫描错误仍按token序优先；无扫描错误的非执行命令，选项区首次新类别决定唯一适用性文案。--json也不把usage文本变LFZ业务JSON。

直连，无自动代理/PAC/WPAD、认证、cookie存储/回发、重定向、跨session池或应用重试。302只返回原Location，不访问新目标；Authorization/Cookie只能调用者显式提交。OS TCP重传不等于应用重试，不能承诺服务端副作用恰一次。HTTPS系统默认链/主机名/有效期验证，无insecure/客户端证书自动选择，不改信任库；本地自签拒绝不等于可信TLS成功，本指南不宣称公网HTTPS已验。

**maxResponseBytes不是wire计数**：合并最终WinHTTP RAW_HEADERS_CRLF完整API文本严格UTF16→UTF8字节（statusline、全部CRLF/末空行、仅去一个终止UTF16 NUL）和平台read得到的原始content-coded body字节。不先lowercase/trim/重建文本计数，不含chunk/TLS framing，不自动解压。恰N允许、>N拒绝，HEAD/204仍计头、0一般连头都容不下。原生头缓冲含NUL最多65536bytes/返回头最多256项；固定8KiB body scratch，不按Content-Length无界预分配。返回pairs等额外有界分配不等于总进程内存额度；精确N测试必须有真实API头证据，不能猜Python wire数。

局部超时/超量/坏UTF8/校验/禁用/Unsupported为约定ValueError，可attempt；DNS/connect/TLS/send/协议/OS错误为IOError。全局cancel/deadline仍ExecutionLimitError不可吞、不补预算；native等待不扣AST步，不因remaining0额外StepBudget。局部总deadline从backend入口（session创建前）开始，覆盖DNS至body完成，不逐read刷新；阶段SetTimeouts不是总截止。同轮观测优先cancel→globaldeadline→localtimeout→限额→OS/协议错→完成，首reason锁存。

WinHTTP async协作取消不是硬返回时界：close request之后仍需HANDLE_CLOSING和最后callback退出，buffer/context安全存活再逆序释放连接/session。不能detach/提前free或声称任意OS网络异常有限时回收。正常返回前末检，是HTTP native本身的poll，不改变其它native规则。

Rust EvalCapabilities新增pub http:bool，手写literal需补http:false或Default更新，现有context三入口和EvalLimits形状不变，旧非context API默认false。库还须检查独立host_diagnostics()和http_diagnostics()两sidecar；result Ok不等于完整成功。CLI主Err保原唯一JSON、诊断先子进程后HTTP写stderr；result Ok且任一诊断非空时stdout空/stderr宿主标题与诊断/exit2（--json宿主例外）。两列表同时非空用旧子进程标题；仅HTTP时标题“lfz: HTTP 资源回收失败”，HTTP每条前缀“lfz: HTTP 回收诊断：”。不让attempt清理sidecar或伪装成功。

仅Windows先验，其它Unsupported，无curl/exec fallback，非沙箱。作者实跑绑定最终18d328候选，证据与实际计数见docs/reports/T18-B-skill-evidence.md；不以旧A产物代替。旧v2不重测/不改输入成绩；R304OPEN，不把功能通过当性能或正式发布。


## 6.8 T19：逐行文件与 JSONL（最终候选）

事实源：三spec §25、docs/reports/T19-contract.md；76内置/13错误类。新增语义已冻结，最终二进制已冻结，以下示例绑定5d2219候选实跑，实际结果见专属报告。旧readFile全文件读取/编码/错误不变，无新CLI flag、能力或Rust context字段。本轮T19交付后停止，不自动T20/automation。历史T18-B的停止边界由本轮新授权覆盖；旧HTTP证据仍仅对应旧字节。

先在项目根创建UTF8无BOM文件Temp/T19-ai/input.jsonl，内容四行：`{"n":1}`、`broken`、空行、`{"n":2}`。保存以下为Temp/T19-ai/jsonl.lfz：

```lfz
#42
let args = argv()
assert(len(args) == 1)
var accepted = 0
var rejected = 0
var total = 0
let cell = {text: ""}
let parseCurrent = () => jsonParse(cell.text)
let result = args[0] |> forEachLine((line, lineNo) => {
    cell.text = line
    let parsed = attempt(parseCurrent)
    if parsed.ok {
        accepted = accepted + 1
        total = total + parsed.value.n
    } else {
        rejected = rejected + 1
    }
    return true
}, 4096)
assert(accepted == 2 && rejected == 2 && total == 3)
assert(result.lines == 4 && !result.stopped)
print(jsonStringify({accepted: accepted, rejected: rejected, total: total, result: result}))
```

先 `./target/release/lfz.exe check Temp/T19-ai/jsonl.lfz`，exit0后再 `./target/release/lfz.exe --max-steps 10000 --timeout-ms 2000 run Temp/T19-ai/jsonl.lfz -- Temp/T19-ai/input.jsonl`。check不执行读取/回调，也不保证名称/类型/业务数据正确。run的限额为可配置例子；无需--allow-process/http。本例只接受示例中的整数n对象；真实JSONL须自行检查schema，JSON语法成功不等于业务结构合法。这里只保留计数，不collect历史记录。

`forEachLine(callback,maxLineBytes,path)`严格三参、data-last；callback是恰两参用户函数`(line:string,lineNo:int)`，返回严格bool，true继续/false早停，nil/0等报TypeError。特殊内置不可一等化，需传函数时用closure包装；同名绑定仍可遮蔽。成功struct字段插入序`lines:int,stopped:bool`，lines含false那次调用，只有false早停令stopped=true，EOF为false。空文件0/false仍完整校验参数和callback arity。jsonStringify按自己的键序输出，不用于证明插入序。

实参先左到右求值，再数量→callback类型→cap类型→path类型→callback恰两参→cap范围→path NUL→资源预检→打开。cap为int 1..16777216；path为string、相对宿主cwd而非module目录，空串沿OS错误，NUL路径ValueError。argv builtin不是两参callback。普通文件读权限沿旧IO，不新增授权开关。

LF唯一分隔、去LF；仅LF前的一个CR被剥离，EOF末CR和孤CR保留。空文件0行，`a`/`a\n`各1行，`\n`1空行，`\n\n`2空行；尾LF不多造末行。BOM/空白/NUL内容/注释样文本原样保留，无loader的#42规则。lineNo从1开始，含空行。

cap计LF前raw bytes，含随后去掉的CR、不含LF；`a\r\n`要2，`a\n`要1，雪要3bytes。恰N允许，N+1失败，坏行不回调；拼好有界行后严格UTF8解码，合法跨8KiB字符可用，不lossy。false后不再解码/解析下一行，即使下一行坏UTF8或超长；允许固定buffer已预读后续bytes。

超长/坏UTF8/cap范围/path NUL/行号溢出为ValueError，可外层attempt捕获整次失败；非普通文件及metadata/open/read失败为IOError，消息`无法逐行读取：{path}`。坏UTF8/超长尚未交付，callback无法恢复；外层attempt不能恢复offset继续，任何错误没有部分成功结果。已有计数/容器/IO副作用不回滚。JSONL只复用jsonParse，在callback内attempt捕获坏JSON继续；空行策略自定，不新增parser/隐式跳行。错误字段class必须`r.error["class"]`，attempt仍固定ok/value/error，error没有file字段。

参数表达式和callback真实AST共享会话步数；native只poll取消Acquire→deadline，不按bytes/块/行扣步或检查remaining。global ExecutionLimitError不可attempt吞或补预算；false正常回调后仍检全局终止。宿主token取消不等于CLI Ctrl-C保证。同步metadata/open/read可能阻塞，协作检查不是硬返回时界。

callback保captured/self/home globals/source/trace与模块共享预算；数据lineNo不冒充LFZ源码span/file，跨模块错误仍指真实LFZ文件。attempt恢复trace/source不恢复预算或副作用。只普通文件，pre/open后metadata检查允许普通文件symlink，不能消灭TOCTOU或保证沙箱；读中修改不是快照/事务/锁。

EOF/false/回调错误/非bool/全局终止/读取解码失败统一finish/drop释放reader/File，外层attempt返回时已释放，无逃逸handle。std Drop不报告OS close错误，无新sidecar，不声称sync_all等于close。真实关闭证据由owner/verifier同进程排他重开/Drop spy提供，本作者不以进程退出或删文件代证。

引擎空间O(当前最长行+固定8KiB)，按实际行有界分配，用户自行collect仍可O(文件)，嵌套调用各自缓冲。小样不证明峰值内存/吞吐或跨平台支持；规模测量另等perf窗口，R304OPEN。作者准备与最终hash证据见docs/reports/T19-skill-evidence.md；不改旧v2输入/成绩，不冒充新Agent盲测。


T19内存边界补充：reader只保有界当前行与8KiB缓冲，不代表任意callback或整个解释器总内存O(cap)。每行新建`attempt(() => jsonParse(line))`会创建UserFn，现func_names保留其诊断元数据，随行数增长。大文件应在循环外一次定义`let cell={text:""}`与`let parseCurrent=()=>jsonParse(cell.text)`，回调中更新`cell.text=line`再`attempt(parseCurrent)`；let字符串不可重绑定，struct字段可改。回调自身也在调用外仅创建一次；计数/固定输出批，别collect全文件或每行创建closure。此规避不改变产品funcID语义，不代替峰值内存实测。


## T20 REPL 工作流（§26，最终候选）

当前规范仍76内置/13错误类，新增`lfz repl`，formatter经评估本轮暂缓，无format命令/check静态规则扩张。依据三spec§26和docs/reports/T20-formatter-assessment.md；本节对应冻结产物 a545d0c2，示例的实际输出见作者验证报告。v3新题另轨，不重写旧v2或比较旧2/8/8/8。

建议Agent开发文件先check再带限额run；REPL用于交互探索，不代模块图check。可用`lfz --max-steps 1000 --timeout-ms 2000 repl -- 中文`；权限仍默认禁用、显式--allow-process/--allow-http沿当前会话，reset不增权，argv是启动快照。repl不接源码来源，`--json`usage拒绝，不提供JSONL输出协议。

以下为pipe输入（每物理行一行，不是一个-e源码），预计最后显示2，再显示5，最终退出0：

```repl
var total=1
total=total+1
total
:reset
5
:quit
```

完整cell立即执行，只执行新cell。函数/块等不完整时继续读；空白/注释不占history，非nil最后值Display一行stdout，nil静默，print不再重复echo。TTY prompt写stderr，pipe无prompt/欢迎语。if闭块即可完整，else须与闭合`}`同物理行组成同cell，否则下一行else不是上个cell续接。裸string不能跨LF，不猜中文错误消息判断完整性。

空pending才识别整行trim的:help/:reset/:quit；未知命令计失败后继续，pending里冒号是源码。input()消费同stdin下一物理行（即使:quit也只是数据），不会重放为REPL源码。EOF完整正常结束，未完成pending用真实编译诊断并exit2；任一cell/命令失败使最终exit2，reset/quit不抹累计失败。

单Interp共享globals，现let/var遮蔽规则沿用；失败前声明/容器/IO/RNG效果保留，无事务回滚。REPL在任何效果前拒import/export，文件run/check模块功能不变。每非空提交来源<repl:N>保至reset，旧函数/default错误指真实定义cell，不用当前文本画caret；reset从1重建但旧outcome可诊断。

每cell重建max_steps与相对timeout（parse后求值起算），不覆盖host绝对deadline或取消token；reset保配置不清已取消token。未捕获资源错可由host开启下一显式cell，不等于attempt可吞ExecutionLimitError。stmt/expr步数与native协作/阻塞边界沿旧规范，不宣称硬时界。

raw pending/cell最多1MiB，累计源码16MiB，4096非空提交（含失败），65536诊断func/default ID。前三类admission是宿主容量错误，不造业务Result；funcID途中耗尽为ExecutionLimitError/ReplCapacity，消息“REPL 会话容量已耗尽”，不可attempt吞，session poison直到reset；已有部分副作用保留。双cleanup诊断也poison，pipe遇poison结束；TTY仅reset/help/quit。pending超cap观察即结束，不无限drain。source/func_names历史snapshot有成本，不能宣称长会话恒定内存。

Rust ReplSession/ReplConfig整个生命周期及析构必须在on_eval_stack，!Send/!Sync；eval_cell返回Result<Option<TracedRun>,ReplHostError>，None为空cell。host错误不伪LFZ错误；配置/来源/poison均按§26。无新UserFn公开字段。formatter暂缓因comments/trivia丢失、管道脱糖/数字原拼写丢失，不能用AST打印冒充保真格式化。

作者准备与实际运行证据见docs/reports/T20-ai-repl-evidence.md；v3协议trace缺失为UNKNOWN，wrapper不证明无旁路。R304OPEN，仅T20交付收口，不恢复自动化。
